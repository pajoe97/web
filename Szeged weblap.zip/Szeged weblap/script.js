const translations = {
  hu: {
    title: "Szeged – A Napfény Városa",
    info: "További információ",
    culture: "Kultúra",
    sights: "Látnivalók",
    gastronomy: "Gasztronómia",
    gallery: "Képgaléria",
    map: "Térkép",
    events: "Események & Fesztiválok",
    history: "Történelem"
  },
  en: {
    title: "Szeged – The City of Sunshine",
    info: "More Information",
    culture: "Culture",
    sights: "Attractions",
    gastronomy: "Gastronomy",
    gallery: "Gallery",
    map: "Map",
    events: "Events & Festivals",
    history: "History"
  },
  de: {
    title: "Szeged – Die Sonnenstadt",
    info: "Weitere Informationen",
    culture: "Kultur",
    sights: "Sehenswürdigkeiten",
    gastronomy: "Gastronomie",
    gallery: "Bildergalerie",
    map: "Karte",
    events: "Veranstaltungen & Festivals",
    history: "Geschichte"
  }
};

function setLanguage(lang) {
  document.querySelector("h1").textContent = translations[lang].title;
  document.querySelector(".btn").textContent = translations[lang].info;
  const headings = document.querySelectorAll(".card h2, section h2, section h3");
  headings.forEach((el) => {
    const key = el.textContent.toLowerCase().replace(/[^a-z]/gi, '');
    for (let t in translations[lang]) {
      if (t.toLowerCase() === key) el.textContent = translations[lang][t];
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  const menuToggle = document.getElementById('menu-toggle');
  const menu = document.getElementById('menu');

  menuToggle.addEventListener('click', () => {
    menu.classList.toggle('show');
  });

  const dropdowns = document.querySelectorAll('.dropdown');

  dropdowns.forEach(dropdown => {
    const dropbtn = dropdown.querySelector('.dropbtn');
    dropbtn.addEventListener('click', e => {
      if (window.innerWidth <= 768) {
        e.preventDefault();
        const dropdownContent = dropdown.querySelector('.dropdown-content');
        dropdownContent.classList.toggle('show');
      }
    });
  });
});
